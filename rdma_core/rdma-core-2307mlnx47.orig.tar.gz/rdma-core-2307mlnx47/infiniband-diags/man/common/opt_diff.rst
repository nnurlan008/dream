.. Define the common option diff

**--diff <filename>**
Load cached ibnetdiscover data and do a diff comparison to the current
network or another cache.  A special diff output for ibnetdiscover
output will be displayed showing differences between the old and current
fabric.  By default, the following are compared for differences: switches,
channel adapters, routers, and port connections.

